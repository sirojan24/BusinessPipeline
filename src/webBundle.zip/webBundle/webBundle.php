<?php

namespace webBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class webBundle extends Bundle
{
}
